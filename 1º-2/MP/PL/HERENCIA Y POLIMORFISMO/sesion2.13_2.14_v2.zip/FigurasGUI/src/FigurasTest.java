/**
 * Programa principal de visualizaci�n de figruas en una ventana
 * mediante la interfaz FiguraGrafica
 * @author Profesores de Metodolog�a de la Programaci�n
 * @version 1.0
 *
 */

import java.util.Random; // generador de n�meros aleatorios

public class FigurasTest {

	// ventana donde mostrar las figuras
	private static MiVentana v = null;
	
	/**
	 * Funci�n main de entrada al programa
	 * @param args
	 */
	public static void main(String[] args) {

        // Observa esto
		FiguraGrafica fg = new Triangulo(1,2,3,4,5,6);
		System.out.println(fg.getEtiqueta());
		
		// Y comprueba que esto va bien
		Circulo c = new CirculoConCentro(2,3,4);
		System.out.println(((FiguraGrafica)c).getEtiqueta());
		
		// Y que esto no va bien, �por qu�?
		//Circulo c1 = new Circulo(4);
		//System.out.println(((FiguraGrafica)c1).getEtiqueta()); -> No se puede castear Circulo ya que no implementa
		//No implementa la interfaz FiguraGrafica
		
		
		// Ahora vamos a crear un vector de objetos con etiquetas
		
		// constantes de total de figuras a crear
		final int TOTALCIRCULOS = 5;
		final int TOTALCIRCULOSCONCENTRO = 5;
		final int TOTALTRIANGULOS = 5;

		// creamos un generador de n�meros aleatorios
		Random gen = new Random();
		
		// array de figuras
		FiguraGeometrica[] figuras = new FiguraGeometrica[TOTALCIRCULOS + TOTALCIRCULOSCONCENTRO + TOTALTRIANGULOS];
		
		// Crea y muestra la ventana de la aplicaci�n
		// iniciaVentana();
		
		// Crea los c�rculos
		for(Integer x = 0; x < TOTALCIRCULOS; x++){
			figuras[x] = new Circulo(gen.nextInt(50));
			// Fijamos el "C"+x como etiqueta
			((Circulo) figuras[x]).setEtiqueta("C"+x.intValue());

		}
		
		// Crea los c�rculos con centro
		for(Integer x = 0; x < TOTALCIRCULOSCONCENTRO; x++){
			figuras[TOTALCIRCULOS + x] = new CirculoConCentro(gen.nextInt(300),gen.nextInt(300),gen.nextInt(50));
			// Fijamos el "C"+x como etiqueta
			if(figuras[x] instanceof CirculoConCentro) ((CirculoConCentro) figuras[x]).setEtiqueta("C"+x.intValue());

		}
		
		// Crea los tri�ngulos
		for(Integer x = 0; x < TOTALTRIANGULOS; x++){
			figuras[TOTALCIRCULOS + TOTALCIRCULOSCONCENTRO + x] = new Triangulo(gen.nextInt(300),gen.nextInt(300),
					gen.nextInt(300),gen.nextInt(300),
					gen.nextInt(300),gen.nextInt(300));
			// Fijamos el "T"+x como etiqueta
			if(figuras[x] instanceof Triangulo) ((Triangulo) figuras[x]).setEtiqueta("T"+ x.intValue());
			
		}
		
		muestraFigurasTexto(figuras);
		// Calcular la superficie total de las figuras del vector
		FiguraGeometrica.areaTotal(figuras);
		// Ordenar las figuras del vector por superficie de menor a mayor 
		System.out.println("El area total de los circulo es mayor que la de los triangulos: " + 
				comparacionSuperficies(figuras));
		ordenaSuperficies(figuras);
		muestraFigurasTexto(figuras);
				
		// mostramos las figuras
		// v.muestraFiguras(figuras);
		v.muestraFiguras(figuras);
		// calculamos y mostramos el �rea total
		System.out.printf("El �rea total es: %.2f\n", FiguraGeometrica.areaTotal(figuras)/* COMPLETAR */);
		
		// Pausa de teclado
		MiTeclado.pulsaIntro();
		
		// destruimos la ventana
		finalizaVentana();
	}
	
	
	private static void muestraFigurasTexto(FiguraGeometrica[] v) {
		for(FiguraGeometrica fg: v) {
			System.out.println(fg);
		}
	}
	
	private static boolean comparacionSuperficies(FiguraGeometrica[] figuras) {
		double area_triangulos = 0.0;
		double area_circulos = 0.0;
		for(int x = 0; x < figuras.length; x++) {
			if(figuras[x] instanceof CirculoConCentro) {
				area_circulos += figuras[x].area();
			}
			if(figuras[x] instanceof Triangulo) {
				area_triangulos += figuras[x].area();
			}
		}
		return (area_circulos > area_triangulos) ? true : false;
		
	}
	
	private static void  ordenaSuperficies(FiguraGeometrica[] figuras){
		for(int i=0;i<figuras.length-1;i++)
			for(int j=i+1;j<figuras.length;j++)
				if(figuras[i].area() < figuras[j].area()){
					FiguraGeometrica temporal = figuras[i];
					figuras[i] = figuras[j];
					figuras[j] = temporal;	
				}
	}
	 
	 private static void iniciaVentana()
	 {
		 v = new MiVentana("Figuras geom�tricas"); 
	 }
	 
	 private static void finalizaVentana()
	 {
		 v.finaliza();
	 }
	 
}
