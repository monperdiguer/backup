
public class Circulo  extends FiguraGeometrica{

	private int radio;
	private String etiqueta;
	
	public Circulo(int r)
	{
		radio = r;
		etiqueta = "C";
	}
	
	public void setRadio(int r)
	{
		radio = r;
	}
	
	public int getRadio()
	{
		return radio;
	}
	
	public double perimetro()
	{
		return 2 * Math.PI * getRadio();
	}
	
	public double area()
	{
		return Math.PI * Math.pow(getRadio(), 2);
	}

	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}
	
	

}
