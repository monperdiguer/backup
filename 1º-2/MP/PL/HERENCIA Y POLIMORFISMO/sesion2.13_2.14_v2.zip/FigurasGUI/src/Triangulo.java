import java.awt.Graphics;
import java.awt.Polygon;

public class Triangulo extends FiguraGeometrica implements FiguraGrafica{

	private String etiqueta;
	private Punto v1;
	private Punto v2;
	private Punto v3;
	
	public Triangulo(int x1, int y1, int x2, int y2, int x3, int y3) {
		v1 = new Punto(x1,y1);
		v2 = new Punto(x2,y2);
		v3 = new Punto(x3,y3);
		etiqueta = "TT";
	}
	
	public Punto getV1(){
		return v1;
	}
	public void setV1(Punto p){
		v1 = p;
	}
	public Punto getV2(){
		return v2;
	}
	public void setV2(Punto p){
		v2 = p;
	}	
	public Punto getV3(){
		return v3;
	}
	public void setV3(Punto p){
		v3 = p;
	}
	
	public String getEtiqueta() {
		return etiqueta;
	}
	
	public void setEtiqueta(String s) {
		this.etiqueta = s;
	}
	
	@Override
	public double area() {
		double semiperimetro = perimetro() / 2;
		double lado_a = Math.sqrt(Math.pow(v2.getX() - v1.getX(),2) + Math.pow(v2.getY() - v1.getY(), 2));
		double lado_b = Math.sqrt(Math.pow(v2.getX() - v3.getX(),2) + Math.pow(v2.getY() - v3.getY(), 2));
		double lado_c = Math.sqrt(Math.pow(v3.getX() - v1.getX(),2) + Math.pow(v3.getY() - v1.getY(), 2));
		double area_heron = Math.sqrt(semiperimetro*(lado_a - semiperimetro)*(lado_b-semiperimetro)*(lado_c-semiperimetro));
		return area_heron;
	}
	
	@Override
	public double perimetro() {
		double lado_a = Math.sqrt(Math.pow(v2.getX() - v1.getX(),2) + Math.pow(v2.getY() - v1.getY(), 2));
		double lado_b = Math.sqrt(Math.pow(v2.getX() - v3.getX(),2) + Math.pow(v2.getY() - v3.getY(), 2));
		double lado_c = Math.sqrt(Math.pow(v3.getX() - v1.getX(),2) + Math.pow(v3.getY() - v1.getY(), 2));
		double perimetro = lado_a + lado_b + lado_c;
		return perimetro;
	}

	@Override
	public String toString() {
		return String.format("Triangulo: " + this.getEtiqueta(),
				"[" + this.getV1().getX() + "," + this.getV1().getY()+ "]\n" +
				"[" + this.getV2().getX() + "," + this.getV2().getY()+ "]\n" +
				"[" + this.getV3().getX() + "," + this.getV3().getY()+ "]\n" + 
				"Perimetro: " + this.perimetro() + "\n" + "Area: " + this.area());
	}

	@Override
	public void pinta(Graphics g) {
		// creamos un array con las Xs y otro con las Ys
		int [] xs = {v1.getX(), v2.getX(), v3.getX()}; int [] ys = {v1.getY(), v2.getY(), v3.getY()};
		// creamos un objeto polígono con esos 3 puntos
		Polygon p = new Polygon(xs, ys, 3); // dibujamos el polígono
		g.drawPolygon(p);
		// dibujamos la etiqueta
		int x = (int)((v1.getX() + v2.getX() + v3.getX())/3); 
		int y = (int)((v1.getY()+ v2.getY() + v3.getY())/3); 
		g.drawString(this.getEtiqueta(), x - 3, y + 4);
		         
		       
		  
		   
		}


	
}
