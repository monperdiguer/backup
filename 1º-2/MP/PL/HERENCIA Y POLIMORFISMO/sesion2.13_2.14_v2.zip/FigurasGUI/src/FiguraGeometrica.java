
public abstract class FiguraGeometrica {

	public abstract double perimetro();
	public abstract double area();
	
	static public double areaTotal(FiguraGeometrica[] figs){
		double areaTotal = 0;
		for(int i=0;i<figs.length;i++)
			areaTotal = figs[i].area() + areaTotal;
		return areaTotal;
	}
	
}

