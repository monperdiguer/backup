/**
 * Programa principal de visualizaci�n de c�rculos en una ventana
 * @author Profesores de Metodolog�a de la Programaci�n
 * @version 1.0
 *
 */



public class CirculosTest {

	// ventana donde mostrar los c�rculos
	private static MiVentana v = null;
	
	/**
	 * Funci�n main de entrada al programa
	 * @param args
	 */
	public static void main(String[] args) {

		// total de c�rculos a mostrar
		final int TOTAL = 10;
		// array de c�rculos con centro
		CirculoConCentro[] circulos = new CirculoConCentro[TOTAL];

		// Crea y muestra la ventana de la aplicaci�n
		// (de momento sin c�rculos)
		iniciaVentana();

		// Genera los circulos
		// centro con X e Y en el rango [1..250]
		// y radio [1..50]
		for(int x = 0; x < TOTAL; x++)
			circulos[x] = new CirculoConCentro(Dado.tira(250),Dado.tira(250),Dado.tira(50));

		// CONSOLA: se muestran los c�rculos en formato texto
		for(CirculoConCentro c: circulos)
			System.out.println(c);	

		// VENTANA: mostramos los circulos (en la ventana)
		muestraCirculos(circulos);

		// esperamos que se pulse la tecla Intro
		// MiTeclado es una clase estatica definida en MiVentana.java
		MiTeclado.pulsaIntro();	


		// cierra y libera los recursos de la ventana
		finalizaVentana();


	}

	/**
	 * Crea y muestra la ventana con el t�tulo "C�rculos"
	 */
	 private static void iniciaVentana()
	 {
		 v = new MiVentana("C�rculos"); 
	 }
	 
	 /**
	  * Finaliza la ventana 
	  */
	 private static void finalizaVentana()
	 {
		 v.finaliza();
	 }
	 
	 /**
	  * Actualiza el array de c�rculos a mostrar por la ventana
	  * y los repinta
	  * @param circulos array de c�rculos a mostrar
	  */
	 private static void muestraCirculos(CirculoConCentro[] circulos)
	 {
	 	// Los muestra graficamente en la ventana
		v.muestraCirculos(circulos);
	 }
}
