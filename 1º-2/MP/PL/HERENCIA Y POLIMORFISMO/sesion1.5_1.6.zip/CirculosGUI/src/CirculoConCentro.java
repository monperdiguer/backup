
public class CirculoConCentro extends Circulo {

	private Punto centro;
	private Circulo circulo;
	
	public CirculoConCentro(int x, int y, double r) {
		super(r);
		centro = new Punto(x,y);
	}
	public Punto getCentro() {
		return centro;
	}
	public void setCentro(int x, int y) {
		this.centro.setX(x);
		this.centro.setY(y);
	}
	public void setCentro(Punto c){
		this.centro = c;
	}
	public double getRadio(){
		return super.getRadio();
	}
	public double perimetro(){
		return 2*Math.PI*circulo.getRadio();
	}
	public double area(){
		return Math.PI*Math.pow(circulo.getRadio(), 2);
	}
	public static boolean solapa(CirculoConCentro A, CirculoConCentro B){
		return ((Punto.distancia(A.getCentro(), B.getCentro())) <= (A.getRadio() + B.getRadio()));
	}
	
	
	public void absorbe(CirculoConCentro c) {
		this.setRadio(c.getRadio());
		this.area();
		int factor_escalado = (int) (1 / (this.getRadio() + c.getRadio()));
		int nuevaX = (int) factor_escalado * (this.getCentro().getX() - c.getCentro().getX());
		int nuevaY = (int) factor_escalado * (this.getCentro().getY() - c.getCentro().getY());
		this.setCentro(nuevaX, nuevaY);
		c.setRadio(0.0);
		c.setCentro(0, 0);
	}
	
	public Punto puntoAzar() {
		Punto p = new Punto(Dado.tira((int) this.getRadio()), Dado.tira((int) this.getRadio()));
		return p;
	}
	
	public static boolean estaDentro(Circulo c, Punto p) {
		return ((p.getX() - c.getRadio() < c.getRadio() ) 
				&& (p.getY() - c.getRadio() < c.getRadio())) ? true : false;
	}
	
	
	
	@Override
	public String toString(){
		String s = String.format("%s", centro);
		s+=String.format("||%.3f\n", this.getRadio());
		return s;
	}
	
	
	
}
