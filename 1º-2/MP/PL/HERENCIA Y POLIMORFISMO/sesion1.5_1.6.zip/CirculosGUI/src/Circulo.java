
public class Circulo {
	
	private double radio;
	private static final double pi = 3.1416;
	
	public Circulo() {
		this.radio = 1.0;
	}
	
	public Circulo(double r) {
		this.setRadio(r);
	}
	public Circulo(Circulo c) {
		this(c.getRadio());
	}
	
	public void setRadio(double r) {
		radio = (r>0) ? r : 0.0;
	}
	
	public double getRadio() {
		return radio;
	}
	
	public double perimetro() {
		return 2*this.getRadio()*pi;
	}
	
	public double area() {
		return pi*Math.pow(this.getRadio(),2);
	}
	
	
	
}
