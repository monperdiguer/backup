/**
 * Programa principal de visualizaci�n de c�rculos en una ventana
 * @author Profesores de Metodolog�a de la Programaci�n
 * @version 1.0
 *
 */



public class CirculosTest {

	// ventana donde mostrar los c�rculos
	private static MiVentana v = null;
	
	/**
	 * Funci�n main de entrada al programa
	 * @param args
	 */
	public static void main(String[] args) {

		// total de c�rculos a mostrar
		final int TOTAL = 10;
		// array de c�rculos con centro
		CirculoConCentro[] circulos = new CirculoConCentro[TOTAL];

		// Crea y muestra la ventana de la aplicaci�n
		// (de momento sin c�rculos)
		iniciaVentana();

		// Genera los circulos
		// centro con X e Y en el rango [1..250]
		// y radio [1..50]
		for(int x = 0; x < TOTAL; x++)
			circulos[x] = new CirculoConCentro(Dado.tira(250),Dado.tira(250),Dado.tira(50));

		// CONSOLA: se muestran los c�rculos en formato texto
		for(CirculoConCentro c: circulos)
			System.out.println(c);	

		// VENTANA: mostramos los circulos (en la ventana)
		muestraCirculos(circulos);
		

		int k = 0;
		System.out.printf("Dame un k: ",k);
		System.out.println();
		
		for(int i = 0; i < k; i++) {
			mueveCirculos(circulos,k);
			muestraCirculos(circulos);
		}
		
		imprimeCirculosAbsorbidos(circulos);
		// esperamos que se pulse la tecla Intro
		// MiTeclado es una clase estatica definida en MiVentana.java
		MiTeclado.pulsaIntro();	

		// cierra y libera los recursos de la ventana
		finalizaVentana();

		

	}

	/**
	 * Crea y muestra la ventana con el t�tulo "C�rculos"
	 */
	 private static void iniciaVentana()
	 {
		 v = new MiVentana("Circulos"); 
	 }
	 
	 /**
	  * Finaliza la ventana 
	  */
	 private static void finalizaVentana()
	 {
		 v.finaliza();
	 }
	 
	 /**
	  * Actualiza el array de c�rculos a mostrar por la ventana
	  * y los repinta
	  * @param circulos array de c�rculos a mostrar
	  */
	 private static void muestraCirculos(CirculoConCentro[] circulos)
	 {
	 	// Los muestra graficamente en la ventana
		v.muestraCirculos(circulos);
	 }
	 private static void mueveCirculos(CirculoConCentro[] circulos, int k) {
		 int kprimera = Dado.tira(k+1)-1;
			int ksegunda = Dado.tira(2);
			
			if(ksegunda == 1)
				ksegunda =- kprimera;
			
			switch(Dado.tira(3)) {
			case 1:
				circulos[k].setRadio(circulos[k].getRadio() + ksegunda);
				break;
			case 2:
				circulos[k].setCentro(circulos[k].getCentro().getX() + ksegunda, circulos[k].getCentro().getY());
				break;
			case 3:
				circulos[k].setCentro(circulos[k].getCentro().getX(), circulos[k].getCentro().getY() + ksegunda);
		 		break;
			}
			for(int i = 0; i < circulos.length; i++) {
				System.out.println(circulos[i].toString());
				muestraCirculos(circulos);
				MiTeclado.pulsaIntro();
			}
			finalizaVentana();
	 }
	 
	 
	 private static void imprimeCirculosAbsorbidos(CirculoConCentro[] circulos) {
		 int i = 0;
		 while(circulos[i] == null) {
			 //Si el metodo es estatico, se invoca con el nombre de la clase
			 if(CirculoConCentro.solapa(circulos[i], circulos[i+1]) && circulos[i] != null && circulos[i+1] != null) {
				 circulos[i].absorbe(circulos[i+1]);
				 i++;
			 }
			 muestraCirculos(circulos);
			 if(i == circulos.length) i = 0;
		 }
	 }
	 
	 public static double interseccion(CirculoConCentro c1, CirculoConCentro c2) {
		 double area_interseccion = 0.0;
		 if(CirculoConCentro.solapa(c1, c2) == false) {
			 return 0.0;
		 } else {
			 
		 }
		 return area_interseccion;
	 }

	 
	 
	 
}
