
public class Punto {
	
	private int coordenada_x;
	private int coordenada_y;
	
	public Punto(int X, int Y) {
		this.coordenada_x = X;
		this.coordenada_y = Y;
	}
	
	public int getX() {
		return coordenada_x;
	}
	
	public int getY() {
		return coordenada_y;
	}
	
	public void setX(int coord_x) {
		this.coordenada_x = coord_x;
	}
	
	public void setY(int coord_y) {
		this.coordenada_y = coord_y;
	}
	
	public static double distancia(Punto A, Punto B) {
		return Math.sqrt(Math.pow(B.getX() - A.getY(),2) + Math.pow(B.getY() - A.getY(), 2));       
	}
	
	@Override
	public String toString() {
		return "( " + this.getX() + ", " + this.getY() + " )";
	}
	
	
}
