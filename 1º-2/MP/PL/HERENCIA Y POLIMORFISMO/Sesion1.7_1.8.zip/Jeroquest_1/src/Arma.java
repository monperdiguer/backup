
public class Arma {
	private String nombre;
	private int ataque;
	
	public Arma(String n, int a) {
		this.setNombre(n);
		this.setAtaque(a);
	}
	
	public void setNombre(String n) {
		this.nombre = n;
	}
	
	public void setAtaque(int n) {
		this.ataque = n;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public int getAtaque() {
		return ataque;
	}
	
	@Override
	public String toString() {
		return "(Arma " + this.getNombre() + ", valor ataque: " + this.getAtaque() + ")";
	}
	
}
