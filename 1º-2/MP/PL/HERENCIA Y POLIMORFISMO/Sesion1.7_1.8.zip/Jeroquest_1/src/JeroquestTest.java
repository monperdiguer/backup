/**
 * Pr�cticas de Metodolog�a de la Programaci�n.
 * Jeroquest - Un ejemplo de Programaci�n orientada a objetos.
 * Programa principal 
 * @author Jorge Puente Peinador y Ramiro Varela Arias
 * @version 1
 *
 */

public class JeroquestTest {

	public static void main(String[] args) {
		
		Momia ramses = new Momia("Ramses");
		Barbaro conan = new Barbaro("Conan");
		
		System.out.println(ramses);
		System.out.println(conan);
		
		// conan ataca a ramses
		int impactos = conan.atacar();
		ramses.defender(impactos);
		
		// si ramses esta vivo ataca a conan
		if (ramses.estaVivo())
			conan.defender(ramses.atacar());
			
		System.out.println(ramses);
		System.out.println(conan);
		
		//Que uno ataque al otro N veces, o hasta que el otro se muera
		int N = 10;
		for(int n = 1; n < N; n++) 
			if(conan.estaVivo())
				conan.defender(ramses.atacar());
		
		System.out.println(ramses);
		System.out.println(conan);

		//Ejercicio 7.1 apartado d
		Barbaro[] vB = { new Barbaro("Conan"),
					new Barbaro("Olaf"),
					new Barbaro("Thor"),
					new Barbaro("Sigurson")};
		
		Momia[] vM = {  new Momia("Ramses"),
				new Momia("Tutankamon"),
				new Momia("Cleopatra"),
				new Momia("Nefertiti")};
		System.out.println("\n\n�A Pelear!\n");
		pelean(vB,vM,N);
		//peleanVidaMax(vB,vM,N);
		
		}
		
		
	
	public static void pelean(Barbaro[] vB, Momia[] vM, int N) {
		
		for(int n = 1; n <=N && HayPersonajesVivos(vM,vB);n++) {
			for(int i = 0; i < vM.length;i++) {
				//Ataca barbaro i a momia aleatoria
				if(vB[i].estaVivo()) {
					int j = Dado.tira(vM.length) - 1;
					if(vM[j].estaVivo())
						vM[j].defender(vB[i].atacar());
				}
				//Ataca momia i a barbaro aleatorio
				if(vM[i].estaVivo()) {
					int j = Dado.tira(vB.length) - 1;
					if(vB[j].estaVivo())
						vB[j].defender(vM[i].atacar());
				}
				imprimeBarbaros(vB);
				imprimeMomias(vM);
			}
			System.out.println("Turno " + n);
		}
		
		
		/*int momiaSelec;
		int barbaroSelect;
		
		for(int i = 0; i < N; i++) {
			//Si i es par, hacemos que en el turno ataquen todos los barbaros
			if(i % 2 == 0) {
				for(int j = 0; j < vB.length; j++) {
					momiaSelec = Dado.tira(vM.length - 1);
					if(estanVivos(vB[j],vM[momiaSelec])) {
							vM[momiaSelec].defender(vB[j].atacar());	
					}
					System.out.println(vB[j]);
					System.out.println(vM[momiaSelec]);
				}
				//Si el turno es impar, que ataquen las momias
				System.out.println("Se acabo el turno de los barbaros\n");
			} else {
				for(int j = 0; j < vM.length; j++) {
					barbaroSelect = Dado.tira(vB.length - 1);
					if(estanVivos(vB[barbaroSelect],vM[j])) {
							vB[barbaroSelect].defender(vM[j].atacar());	
					}
					System.out.println(vB[barbaroSelect]);
					System.out.println(vM[j]);
				}
				System.out.println("Se acabo el turno de las momias\n");
			}
			System.out.println("Se ha acabado el turno " + i +"\n");
		}*/
	}
	
	//Apartado e analogo al apartado d
	public static void peleanVidaMax(Barbaro[] vB, Momia[] vM, int N) {
		
		for(int n = 1; n <=N && HayPersonajesVivos(vM,vB);n++) {
			for(int i = 0; i < vM.length;i++) {
				//Ataca barbaro i a momia aleatoria
				if(vB[i].estaVivo()) {
					Momia m = momiaVidaMax(vM);
					if(m.estaVivo())
						m.defender(vB[i].atacar());
				}
				//Ataca momia i a barbaro aleatorio
				if(vM[i].estaVivo()) {
					Barbaro b = barbaroVidaMax(vB);
					if(b.estaVivo())
						b.defender(vM[i].atacar());
				}
				imprimeBarbaros(vB);
				imprimeMomias(vM);
			}
			System.out.println("Turno " + n);
		}
	}
	

	
	public static boolean HayPersonajesVivos(Momia[] vM, Barbaro[] vB) {
		return HayVivos(vM) && HayVivos(vB);
	}
	
	public static boolean HayVivos(Momia[] v) {
		for(int i = 0; i < v.length;i++)
			if(v[i].estaVivo()) return true;
		return false;
	}
	public static boolean HayVivos(Barbaro[] v) {
		for(int i = 0; i < v.length;i++)
			if(v[i].estaVivo()) return true;
		return false;
	}
	
	public static void imprimeBarbaros(Barbaro[] v) {
		for(int i = 0; i < v.length;i++) {
			System.out.println(v[i].toString());
		}
	}
	public static void imprimeMomias(Momia[] v) {
		for(int i = 0; i < v.length;i++) {
			System.out.println(v[i].toString());
		}
	}
	public static Momia momiaVidaMax(Momia[] v) {
		Momia max = null;
		for(int i = 0; i < v.length;i++)
			if(v[i].getCuerpo() > max.getCuerpo()) max = v[i];
		return max;
	}
	public static Barbaro barbaroVidaMax(Barbaro[] v) {
		Barbaro max = null;
		for(int i = 0; i < v.length;i++)
			if(v[i].getCuerpo() > max.getCuerpo()) max = v[i];
		return max;
	}

}
