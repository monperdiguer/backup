
public abstract class Heroe extends Personaje {
	
	protected String jugador;
	protected Arma arma;
	private static final int UMBRAL_ATAQUE = 3;
	
	public Heroe(String suNombre, int suMovimiento, int suAtaque, int suDefensa, int suCuerpo, Arma suArma) {
		super(suNombre, suMovimiento, suAtaque, suDefensa, suCuerpo);
		arma = suArma;
	}
	
	public void setArma(Arma arma) {
		this.arma = arma;
	}
	
	public String getNombre() {
		return jugador;
	}
	
	public void setNombre(String n) {
		this.jugador = n;
	}
	
	@Override
	public int getAtaque() {
		if(this.arma == null)
			return this.getAtaque();
		else
			return this.arma.getAtaque();
	}
	
	
	@Override
	public int defender(int impactos) {
		// se tratan de bloquear los impactos con la defensa
		for(int totalDadosDefensa = defensa; (impactos > 0) && (totalDadosDefensa > 0);
		totalDadosDefensa--)
			if (Dado.tira() > 4) // se necesita un 5 o 6 para detener un impacto
				impactos --;
		
		// si hay algun impacto se resta de la vida
		if(impactos > 0)
		{
			// la vida de un personaje no puede ser menor que cero
			cuerpo = Math.max(0, cuerpo - impactos);
			System.out.printf("El heroe " + this.getNombre() + " no puede bloquear %d impactos%s", impactos,
					(estaVivo() ? "\n" : " y se muere\n"));
		}
		else
		{
			System.out.printf("El heroe bloquea totalmente el ataque\n");
		}
		
		return impactos;
	}

	@Override
	public String toString() {
		return String.format("El heroe: %s ", this.getNombre());
	}
	
	
}
