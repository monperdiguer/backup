
public class MomiaRabiosa extends Momia {

	public MomiaRabiosa(String suNombre) {
		super(suNombre);
	}
	public int getAtaque() {
		return super.getAtaque()*2;
	}
	@Override
	public int defender(int impactos)
	{
		if(impactos > 0)
		{
			// la vida de un personaje no puede ser menor que cero
			cuerpo = Math.max(0, cuerpo - impactos);
			System.out.printf("La momia rabiosa" + this.getNombre() + " no puede bloquear %d impactos %s", impactos, 
					(estaVivo() ? "\n" : " y se muere\n"));
		}
		return impactos;
	}
	public String toString()
	{
		return String.format("La Momia Rabiosa: %s", super.toString());
	}
	

}
