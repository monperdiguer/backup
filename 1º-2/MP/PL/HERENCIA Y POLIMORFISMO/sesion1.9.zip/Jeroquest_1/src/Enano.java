
public class Enano extends Heroe {
	// valores iniciales de los atributos
		protected static final int MOVIMIENTO = 7;
		protected static final int ATAQUE = 1;
		protected static final int DEFENSA = 2;
		protected static final int CUERPO = 8;

		/**
		 * Crea un b�rbaro a partir de su nombre
		 * @param suNombre nombre del b�rbaro
		 */
		public Enano(String suNombre)
		{
			// fijamos los atributos con los valores iniciales
			super(suNombre, MOVIMIENTO, ATAQUE, DEFENSA, CUERPO, (Dado.tira(2) == 1 ? new Arma("Hacha de Mano",3) : null));
		}
		
		//Sobreescribimos el metodo atacar para tener en cuenta el arma
		public int getAtaque() {
			return super.getAtaque();
		}
		
		/** 
		 * El b�rbaro se defiende de un ataque
		 * (Implementaci�n de m�todo abstracto heredado)
		 * @param impactos el total de impactos que tiene que intentar bloquear y sino sufrir
		 * @return el numero de heridas sufridas
		 */
		public int defender(int impactos)
		{
			return super.defender(impactos);
		}
		
		/** 
		 * Genera la versi�n String imprimible del objeto
		 *  (M�todo reescrito)
		 * @return La versi�n como String imprimible del barbaro
		 */
		public String toString()
		{
			return String.format("El Enano: %s + %s", 
					super.toString(), this.arma.toString());
		}


}
