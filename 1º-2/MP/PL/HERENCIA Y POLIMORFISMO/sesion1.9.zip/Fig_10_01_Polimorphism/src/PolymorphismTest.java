// Fig. 10.1: PolymorphismTest.java
// Assigning superclass and subclass references to superclass and
// subclass variables.

public class PolymorphismTest  
{
   public static void main( String[] args ) 
   {
      // assign superclass reference to superclass variable
      CommissionEmployee commissionEmployee = new CommissionEmployee( 
         "Sue", "Jones", "222-22-2222", 10000, .06 );                    

      // assign subclass reference to subclass variable
      BasePlusCommissionEmployee basePlusCommissionEmployee = 
         new BasePlusCommissionEmployee( 
         "Bob", "Lewis", "333-33-3333", 5000, .04, 300 );         

      // invoke toString on superclass object using superclass variable
      System.out.printf( "%s %s:\n\n%s\n\n", 
         "Call CommissionEmployee's toString with superclass reference ",
         "to superclass object", commissionEmployee.toString() );

      // invoke toString on subclass object using subclass variable      
      System.out.printf( "%s %s:\n\n%s\n\n", 
         "Call BasePlusCommissionEmployee's toString with subclass",
         "reference to subclass object", 
         basePlusCommissionEmployee.toString() );

      // POLIMORFISM: invoke toString on subclass object using superclass variable
      CommissionEmployee commissionEmployee2 = 
         basePlusCommissionEmployee; 
      System.out.printf( "%s %s:\n\n%s\n", 
         "Call BasePlusCommissionEmployee's toString with superclass",
         "reference to subclass object", commissionEmployee2.toString() );
      
      
      
      BasePlusCommissionEmployee bpce1 = 
    		  new BasePlusCommissionEmployee("Willy", "Lewis", "333-33-3333", 50000, .04, 500 );
      BasePlusCommissionEmployee bpce2 = 
    		  new BasePlusCommissionEmployee("Paco", "Lewis", "333-33-3333", 50000, .02, 200 );
      BasePlusCommissionEmployee bpce3 = 
    		  new BasePlusCommissionEmployee("Sue", "Lewis", "333-33-3333", 50000, .2, 100 );
      BasePlusCommissionEmployee bpce4 = 
    		  new BasePlusCommissionEmployee("Bobby", "Lewis", "333-33-3333", 50000, .4, 300 );
      
      CommissionEmployee ce1= 
    		  new CommissionEmployee("Sue2", "Jones", "222-22-2222", 10000, .06 );
      CommissionEmployee ce2= 
    		  new CommissionEmployee("Sue3", "Jones", "222-22-2222", 20000, .01 );
      CommissionEmployee ce3 =
    		  new CommissionEmployee("Sue4", "Jones", "222-22-2222", 1000,   .1 );
      CommissionEmployee ce4 = 
    		  new CommissionEmployee("Sue5", "Jones", "222-22-2222", 100,    .2 );
      
      CommissionEmployee[] v = {bpce1, bpce2, bpce3, bpce4, ce1, ce2, ce3, ce4};
      
      System.out.println("El que mas gana es: \n" + masGana(v));
      ordenaSueldos(v);
      muestra(v);
      
   } // end main
   
   
   public static CommissionEmployee masGana(CommissionEmployee[] cE) {
	   CommissionEmployee maximo = cE[0];
	   for(int i = 0; i < cE.length;i++) {
			   if (cE[i].earnings() > maximo.earnings()) {
				   maximo = cE[i];
			   }
		   
	   }
	   return maximo;
   }
   
   private static void ordenaSueldos(CommissionEmployee vector[]) {
	   CommissionEmployee temp = vector[0];
	   for(int i = 0; i < vector.length - 1; i++) {
		   for(int j = i + 1; j < vector.length; j++) {
			   if(vector[i].earnings() > vector[j].earnings()) {
				   temp = vector[i];
				   vector[i] = vector[j];
				   vector[j] = temp;
			   }
		   }
	   }
   }
   private static void muestra(CommissionEmployee vector[]) {
	   for(CommissionEmployee e: vector) {
		   System.out.println(e.toString());
		   System.out.println("\n");
	   }
   }
   
   
} // end class PolymorphismTest

/**************************************************************************
 * (C) Copyright 1992-2010 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
