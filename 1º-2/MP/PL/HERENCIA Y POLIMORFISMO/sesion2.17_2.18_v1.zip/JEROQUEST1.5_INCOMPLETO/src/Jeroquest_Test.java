


// Demo de la clase jeroquest



/**
 * Programa principal de prueba del juego Jeroquest
 * @author Jorge Puente Peinador
 * @version 1.5
 *
 */
public class Jeroquest_Test {

	public static void main(String[] args) {

		Jeroquest jq = new Jeroquest();
		// vamos a jugar una partida de 3 Héroes contra 4 Monstruos
		// en un tablero de 7 por 10
		// en 20 rondas
		jq.nuevaPartida(3,10,5,5,20);
		jq.aJugar();	
	}

}

