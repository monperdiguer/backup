
public class Estadistica {

	public static int DAÑO_HEROES = 0;
	public static int DAÑO_MONSTRUOS = 0;

	
	
}
