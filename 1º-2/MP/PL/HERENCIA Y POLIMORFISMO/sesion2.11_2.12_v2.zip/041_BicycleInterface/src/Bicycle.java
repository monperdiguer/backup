/* 
 * Clase Bicycle, implementa el interface Driveable
 *
 **/

abstract class Bicycle {

       private int cadence;
       private int speed;
       private int gear;
       private int direction; // 0 - 359

       
       public Bicycle() {
    	   		this.cadence = 0;
    	   		this.speed = 0;
    	   		this.gear = 1;
    	   		this.direction = 0;
    	   		
       }
 
       public Bicycle(int c, int s, int g, int d) {
    	   		this.setCadence(c);
    	   		this.setSpeed(s);
    	   		this.setGear(g);
    	   		this.setDirection((d>=0 && d<=359) ? d : 0);
       	}
       
       
       
       public void setCadence(int newValue) {
            cadence = newValue;
       }
       
       public int getCadence() {
           return cadence;
       }

       public void setGear(int newValue) {
            gear = newValue;
       }
       
       public int getGear() {
           return gear;
       }
       
       public void setSpeed(int newValue) {
           speed = newValue;
       }
      
       public int getSpeed() {
           return speed;
       }
       
       public void setDirection(int newValue) {
           direction = newValue;
       }
      
       public int getDirection() {
           return direction;
       }
       
       // implementacion de la interface Driveable

       public void speedUp(int increment) {
            speed = speed + increment;   
       }

       public void slowDown(int decrement) {
            speed = speed - decrement;
       }
       
       public void turnLeft(int amount) {
    	   direction = (direction + amount) % 360;
       }
       
       public void turnRight(int amount) {
    	   direction = (360 + direction - amount) % 360;
       }
       //Aqui termina la implementacion de la interfaz  Driveable
       
       void printStates() {
    	    System.out.println(" -- Bicycle -- ");
            System.out.println("cadence:"+cadence+" speed:"+speed+" gear:"+gear+" direction:"+direction);
       }
}
