/**
 * Clase RoadBike, hereda de Bycicle
 * y sobreescribe el metodo printState
 * 
 */

public class RoadBike extends Bicycle implements Driveable {
	
  private int tireWidth; // In millimeters (mm)

  public RoadBike() {
	  super();
	  tireWidth = 120;
  }
  
  
  public RoadBike(int startCadence, int startSpeed, int startGear, int direction, int newTireWidth){
    super(startCadence, startSpeed, startGear,direction);
    this.setTireWidth(newTireWidth);
  }

  public int getTireWidth(){
    return this.tireWidth;
  }

  public void setTireWidth(int newTireWidth){
    this.tireWidth = newTireWidth;
  }

  public void printStates(){
	System.out.println(" -- RoadBike -- ");  
    super.printStates();
    System.out.println("The RoadBike has " + getTireWidth()
            + " MM tires.");
  }

}

