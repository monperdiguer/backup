/**
 * Clase MountainBike, hereda de Bycicle
 * y sobreescribe el metodo printState
 * 
 */

public class MountainBike extends Bicycle implements Driveable {
	
  private String suspension;

  public MountainBike() {
	  super();
	  suspension = "Dura";
  }
  
  
  public MountainBike(int startCadence, int startSpeed, int startGear,int direction, String suspensionType){
    super(startCadence, startSpeed, startGear, direction);
    this.setSuspension(suspensionType);
  }

  public String getSuspension(){
    return this.suspension;
  }

  public void setSuspension(String suspensionType){
    this.suspension = suspensionType;
  }

  public void printStates(){
	System.out.println(" -- MountainBike -- ");  
    super.printStates();
    System.out.println("The MountainBike has a " + getSuspension()
            + " suspension.");
  }
} 





