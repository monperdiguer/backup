
public class HourlyEmployee extends Employee {

	private double wage;
	private int hours;
	
	public HourlyEmployee(String first, String last, String ssn, double w, int h) {
		super(first, last, ssn);
		this.wage = w;
		this.hours = h;
	}

	@Override
	public double getPaymentAmount() {
		if (this.getHours() < 40) {
			return wage * hours;
		} else {
			return hours * 1.5;
		}
	}

	public double getWage() {
		return wage;
	}

	public void setWage(double wage) {
		this.wage = wage;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	@Override
	public String toString() {
		return "HourlyEmployee [wage=" + wage + ", hours=" + hours + "]";
	}
	
	
	

}
