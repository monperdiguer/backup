// Fig. 10.9: PayrollSystemTest.java
// Employee hierarchy test program.

public class PayrollSystemTest 
{
   public static void main( String[] args ) 
   {
      // create subclass objects
      SalariedEmployee salariedEmployee = 
         new SalariedEmployee( "John", "Smith", "111-11-1111", 800.00 );
      HourlyEmployee hourlyEmployee = 
         new HourlyEmployee( "Karen", "Price", "222-22-2222", 16.75, 40 );
      CommissionEmployee commissionEmployee = 
         new CommissionEmployee( 
         "Sue", "Jones", "333-33-3333", 10000, .06 );
      BasePlusCommissionEmployee basePlusCommissionEmployee = 
         new BasePlusCommissionEmployee( 
         "Bob", "Lewis", "444-44-4444", 5000, .04, 300 );

      System.out.println( "Employees processed individually:\n" );
      
      System.out.printf( "%s\n%s: $%,.2f\n\n", 
         salariedEmployee, "earned", salariedEmployee.earnings() );
      System.out.printf( "%s\n%s: $%,.2f\n\n",
         hourlyEmployee, "earned", hourlyEmployee.earnings() );
      System.out.printf( "%s\n%s: $%,.2f\n\n",
         commissionEmployee, "earned", commissionEmployee.earnings() );
      System.out.printf( "%s\n%s: $%,.2f\n\n", 
         basePlusCommissionEmployee, 
         "earned", basePlusCommissionEmployee.earnings() );

      // create four-element Employee array
      Employee[] employees = new Employee[ 4 ]; 

      // initialize array with Employees
      employees[ 0 ] = salariedEmployee;
      employees[ 1 ] = hourlyEmployee;
      employees[ 2 ] = commissionEmployee; 
      employees[ 3 ] = basePlusCommissionEmployee;

      System.out.println( "Employees processed polymorphically:\n" );
      
      // POLIMORFISM: generically process each element in array employees
      for ( Employee currentEmployee : employees ) 
      {
         System.out.println( currentEmployee ); // invokes toString

         // determine whether element is a BasePlusCommissionEmployee
         if ( currentEmployee instanceof BasePlusCommissionEmployee ) 
         {
            // downcast Employee reference to 
            // BasePlusCommissionEmployee reference

        	 	
            ((BasePlusCommissionEmployee) currentEmployee).
            setBaseSalary( 1.10 * ((BasePlusCommissionEmployee) currentEmployee).
            		getBaseSalary() );

            System.out.printf( 
               "new base salary with 10%% increase is: $%,.2f\n",
               ((BasePlusCommissionEmployee) currentEmployee).getBaseSalary() );
         } // end if

         System.out.printf( 
            "earned $%,.2f\n\n", currentEmployee.earnings() );
      } // end for

      // get type name of each object in employees array
      for ( int j = 0; j < employees.length; j++ )
         System.out.printf( "Employee %d is a %s\n", j, 
            employees[ j ].getClass().getName() ); 
      System.out.println("El que mas gana es: ");
      System.out.println(masGana(employees).toString() + "\n\n");
      
      ordenaSueldos(employees);
      muestra(employees);
      System.out.println("Vamos a cambiar los CommissionRate del vector según un entero: ");
      cambiarComissionRate(employees, 0.5, 1); //Solo está disponible que el entero esté entre 0 y 2
      muestra(employees);
      
   } // end main
   
   public static Employee masGana(Employee[] cE) {
	   Employee maximo = cE[0];
	   for(int i = 0; i < cE.length;i++) {
			   if (cE[i].earnings() > maximo.earnings()) {
				   maximo = cE[i];
			   }
		   
	   }
	   return maximo;
   }
   
   private static void ordenaSueldos(Employee vector[]) {
	   Employee temp = vector[0];
	   for(int i = 0; i < vector.length - 1; i++) {
		   for(int j = i + 1; j < vector.length; j++) {
			   if(vector[i].earnings() > vector[j].earnings()) {
				   temp = vector[i];
				   vector[i] = vector[j];
				   vector[j] = temp;
			   }
		   }
	   }
   }
   private static void muestra(Employee vector[]) {
	   for(Employee e: vector) {
		   System.out.println(e.toString());
		   System.out.println("\n");
	   }
   }
   
   public static void cambiarComissionRate( Employee[] employees, double inc, int aQuien){
	   for(Employee temp: employees) {
		   if(aQuien < 0 || aQuien > 2) {
			   System.out.println("Has introducido un aQuien invalido");
		   }
		   if(aQuien == 0 && (temp instanceof CommissionEmployee)) {
				   ((CommissionEmployee) temp).
				   setCommissionRate(((CommissionEmployee) temp).getCommissionRate() + inc);
		   } 
		   if(temp.getClass().getName().equals("CommissionEmployee")) {
			   ((CommissionEmployee) temp).
			   setCommissionRate(((CommissionEmployee) temp).
					   getCommissionRate() + inc);
		   }
		   if(aQuien == 2 && (temp instanceof BasePlusCommissionEmployee)) {
			   ((CommissionEmployee) temp).
			   setCommissionRate(((CommissionEmployee) temp).
					   getCommissionRate() + inc);
		   }
	   }
   }
   
   
   
} // end class PayrollSystemTest

/**************************************************************************
 * (C) Copyright 1992-2010 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
