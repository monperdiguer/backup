/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;

/**
 * Class that represents a bounty hunter character in the game
 *
 * @author Programming Methodology Professors
 */
public class BountyHunter extends Character {

	// initial values for the attributes
	protected static final int MOVEMENT = 10;
	protected static final int ATTACK = 4;
	protected static final int DEFENCE = 4;
	protected static final int BODY = 6;

	private DynamicVectorCharacters targets; // exercise 3
	private int benefit; // exercise 5
	private final int FEE; // exercise 5b

	/**
	 * Create a mummy from its name
	 * 
	 * @param name name of the mummy
	 */
	public BountyHunter(String name, int fee) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setTargets(new DynamicVectorCharacters()); // exercise 3
		setBenefit(0); // exercise 5
		FEE = fee; // exercise 5b
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/
	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'H';
	}

	/************************************************
	 * Interface GraphicPiece implementation
	 **********************************************/

	// Icon of a mummy
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/hunter.png"));

	@Override
	public Icon getImage() {
		return icon;
	}

	// exercise 2: they defend themselves as the heroes
	@Override
	public int defend(int impacts) {
		int wounds = 0;

		// it tries to block the impacts with the defence
		for (int totalDefenceDices = getDefence(); (impacts > 0) && (totalDefenceDices > 0); totalDefenceDices--)
			if (Dice.roll() > 4) // a 5 or 6 necessary to block an impact
				impacts--;

		// if any unblocked impact, decrement body points
		if (impacts > 0) {
			// the life of a character cannot be lower then zero
			wounds = Math.min(getBody(), impacts);
			setBody(getBody() - wounds);
		}

		return wounds;
	}

	// exercise 2: the defence dice are doubled if they have already benefit
	@Override
	public int getDefence() {
		if (this.getBenefit() > 0)
			return 2 * super.getDefence();

		return super.getDefence();
	}

	// exercise 3
	public DynamicVectorCharacters getTargets() {
		return targets;
	}

	public void setTargets(DynamicVectorCharacters targets) {
		this.targets = targets;
	}

	// exercise 3
	public void fillTargets() {
		// restart the list
		setTargets(new DynamicVectorCharacters());
		for (Character c : Controller.getInstance().getCurrentGame().getCharacters())
			if (!c.equals(this) && c.isAlive() && c != this && Dice.roll(4) == 1)
				getTargets().add(c);
	}

	// exercise 4
	@Override
	public boolean isEnemy(Character c) {
		return getTargets().member(c) || c instanceof Rewardable;
	}

	// exercise 5
	public int getBenefit() {
		return benefit;
	}

	public void setBenefit(int benefit) {
		this.benefit = benefit;
	}

	// exercise 5c
	private int computeReward(Character c) {
		int reward = 0;
		if (c instanceof Rewardable)
			reward += ((Rewardable) c).getReward();
		if (getTargets().member(c))
			reward += FEE;
		return reward;
	}

	// exercise 5
	@Override
	public boolean actionCombat() {
		// Attack a random enemy
		DynamicVectorCharacters targets = validTargets();

		if (targets.length() > 0) {
			// exercise 5: choose the one with highest benefit, if there is a draw, keep the
			// last
			Character target = targets.get(0);
			for (int i = 1; i < targets.length(); i++)
				if (computeReward(targets.get(i)) >= computeReward(target))
					target = targets.get(i);

			String message = String.format("%s %s attacks to %s %s", getName(), getPosition(), target.getName(),
					target.getPosition());
			Controller.getInstance().updateGraphicalPiece(null, message);
			this.combat(target);
			return true;
		}
		return false;
	}

	// exercise 5 (or alternatively include the 'if' block in actionCombat()
	// checking that the target is not alive after the combat
	@Override
	public void combat(Character c) {
		super.combat(c);
		if (!c.isAlive()) {
			Controller.getInstance().updateGraphicalPiece(null,
					String.format("%s has killed %s incrementint his benefit in %d coins", this.getName(), c.getName(),
							computeReward(c)));
			setBenefit(getBenefit() + computeReward(c));
		}
	}

	// exercise 6
	public boolean continueGame() {
		// first update the list of particular targets, removing the dead ones
		int i = 0;
		while (i < getTargets().length()) {
			Character c = getTargets().get(i);
			if (!c.isAlive())
				getTargets().remove(getTargets().position(c));
			else
				i++;
		}

		// Next, if no more rewardable alive characters and the list of particular
		// targets is empty, the bounty hunter leaves the game (disappearing from it)
		// and shows a message with the total benefit
		if (getTargets().length() > 0) // the list of particular targets is not empty
			return true;

		for (Character c : Controller.getInstance().getCurrentGame().getCharacters())
			if (c.isAlive() && c instanceof Rewardable) // there is any alive rewardable character
				return true;

		// no particular targets, nor rewardables, then leaving the game
		Controller.getInstance().updateGraphicalPiece(this, String.format(
				"%s leaves the game because there are no particular targets not rewardable characters alive. Total benefit obtained: %d coins ",
				this.getName(), this.getBenefit()));
		this.setBody(-1); // setting body to -1
		// can be also removed from the board here, or in Controller
		return false;
	}

	@Override
	public String toString() {
		return String.format("%s %s current benefit=%d", super.toString(),
				getTargets() != null ? " list of targets = [ " + getTargets().toString() + "]"
						: " does not have targets in the list",
				getBenefit());
	}
}
