package jeroquest.units;

public interface Rewardable { //exercise 4	
	//exercise 5a
	int getReward();
	void setReward(int amount);
}
