/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;

/**
 * Class that represents a Mummy monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Mummy extends Monster implements Rewardable // exercise 4
{

	// initial values for the attributes
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 3;
	protected static final int DEFENCE = 4;
	protected static final int BODY = 2;
	private int reward; // exercise 5a

	/**
	 * Create a mummy from its name
	 * 
	 * @param name name of the mummy
	 */
	public Mummy(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setReward(4 + Dice.roll(6)); // exercise 5a
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'M';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Icon of a mummy
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/mummy.gif"));

	@Override
	public Icon getImage() {
		return icon;
	}

	// exercise 5a
	@Override
	public int getReward() {
		return reward;
	}

	// exercise 5a
	@Override
	public void setReward(int amount) {
		reward = amount;
	}

	// exercise 5
	@Override
	public void resolveTurn() {
		setReward(getReward() + 10);
		super.resolveTurn();
	}

	@Override
	public String toString() {
		return String.format("%s current reward=%d", super.toString(), getReward());
	}
}
