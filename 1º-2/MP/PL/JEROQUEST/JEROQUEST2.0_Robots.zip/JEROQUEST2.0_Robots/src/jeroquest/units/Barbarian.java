/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.logic.Controller;

/**
 * Class that represents a Barbarian hero character in the game
 *
 * @author Programming Methodology Professors
 */
public class Barbarian extends Hero {
	// initial values for the attributes
	protected static final int MOVEMENT = 7;
	protected static final int ATTACK = 1;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 8;

	/**
	 * Create a barbarian from its name and the player name
	 * 
	 * @param name   barbarian's name
	 * @param player name of the player that controls it
	 */
	public Barbarian(String name, String player) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY, player, new Weapon("Broadsword", 3));
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'B';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Barbarian icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/barbarian.gif"));

	@Override
	public Icon getImage() {
		return icon;
	}

	// 5-
	private RobotBueno robotControlado;

	public RobotBueno getRobotControlado() {
		return robotControlado;
	}

	public void setRobotControlado(RobotBueno robotControlado) {
		this.robotControlado = robotControlado;
	}

	public void controlRobot() {
		if (getRobotControlado() == null) // si no controla ningun robot
			for (Character c : Controller.getInstance().getCurrentGame().getCharacters()) {
				if (c.isAlive() && c instanceof RobotBueno && !((RobotBueno) c).isControlado()) { 
					// el robot esta vivo y no está siendo controlado
					setRobotControlado((RobotBueno) c);
				}
			}
	}

	@Override
	public void resolveTurn() {
		super.resolveTurn();
		if (getRobotControlado() != null && Dice.roll(2) == 1) { // barbaro que controla robot con 50% se rebela
			getRobotControlado().setControlado(false);
			setRobotControlado(null);
		}
	}

	@Override
	public int getAttack() {
		int attack = super.getAttack();
		if (getRobotControlado() != null) // si controla algo
			return attack + getRobotControlado().getAttack(); // suma su ataque 
		return attack;
	}

}
