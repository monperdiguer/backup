package jeroquest.units;

public interface Aturdible {

	public void setDazed(boolean b);

	public boolean isDazed();
}
