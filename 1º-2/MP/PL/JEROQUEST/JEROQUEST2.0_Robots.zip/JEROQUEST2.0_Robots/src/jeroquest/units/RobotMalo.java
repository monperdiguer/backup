package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;

public class RobotMalo extends Monster {
	
	protected static final int MOVEMENT = 2;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 2;

	public RobotMalo(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setPersonajesAtacados(new DynamicVectorCharacters());
	}
	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'C';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/robot_C.png"));

	@Override
	public Icon getImage() {
		return icon;
	}
	
	// 3-
	private boolean fallo;
	
	public boolean isFallo() {
		return fallo;
	}

	public void setFallo(boolean fallo) {
		this.fallo = fallo;
	}
	
	@Override
	public int defend(int impacts) {
		int impactosRecibidos = super.defend(impacts);
		if (impactosRecibidos > 0) { // si recibe más de un impacto
			setFallo(true); // falla
		}
		return impactosRecibidos;
	}

	@Override
	public void combat(Character c) { 
		// 3-
		if (c instanceof Monster) // si ataca a otros monster
			setFallo(false); // ya no falla
		
		int impacts = this.attack();
		
		// 4-
		if (getPersonajesAtacados().member(c)) { // ya le habia atacado
			impacts *= 2; // se doblan los impactos
		}else {
			getPersonajesAtacados().add(c); // se añade a la lista de atacados
		}
		
		int wounds = c.defend(impacts);
		if (!c.isAlive()) {
			Controller.getInstance().getCurrentGame().getBoard().removePiece(c);
		}
		if (wounds > 0) {
			Controller.getInstance().updateGraphicalPiece(c, String.format("%s cannot block %d impacts%s", c.getName(),
					wounds, (c.isAlive() ? "" : " and dies")));
		} else {
			Controller.getInstance().updateGraphicalPiece(null, String.format("%s blocks the attack", c.getName()));
		}
		
	}
	
	@Override
	public boolean isEnemy(Character c) {
		if (isFallo()) // si falla
			return true; // c siempre será un personaje
		return super.isEnemy(c);
	}


	// 4-
	private DynamicVectorCharacters personajesAtacados;

	public DynamicVectorCharacters getPersonajesAtacados() {
		return personajesAtacados;
	}

	public void setPersonajesAtacados(DynamicVectorCharacters personajesAtacados) {
		this.personajesAtacados = personajesAtacados;
	}
	
	
}
