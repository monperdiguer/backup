package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Position;
import jeroquest.logic.Controller;

public class RobotBueno extends Hero {

	protected static final int MOVEMENT = 2;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 2;

	public RobotBueno(String name, String player) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY, player, null);
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'J';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/robot_J.png"));

	@Override
	public Icon getImage() {
		return icon;
	}

	// 2-
	public boolean isAgresivo() {
		return agresivo;
	}

	public void setAgresivo(boolean agresivo) {
		this.agresivo = agresivo;
	}

	private boolean agresivo;

	@Override
	public void resolveTurn() {
		// 5- isControlado se podria comprobar tambien en defed, depende cómo
		// interpretamos "acción" si se hace aqui y en algun sitio más lo daría por
		// bueno
		if (!isControlado()) { // si no esta controlado se mueve
			// 2-
			if (isAgresivo()) { // si es agresivo ataca
				actionCombat();
				setAgresivo(false);
			}
			actionMovement();
		}
	}

	@Override
	public int defend(int impacts) {
		setAgresivo(true);
		return super.defend(impacts);
	}

	// 5-
	private boolean controlado;

	public boolean isControlado() {
		return controlado;
	}

	public void setControlado(boolean controlado) {
		this.controlado = controlado;
	}

	// 6-
	public void aturdir() {
		for (Character c : Controller.getInstance().getCurrentGame().getCharacters()) {
			if (c.isAlive() && c instanceof Aturdible && casillasAdyacentes(c.getPosition())) { // aturdible en casillas adyacente
				((Aturdible) c).setDazed(true);
			}
		}
	}
	
	// una forma es así, según ChatGPT. También se podria mirar con todas las combinaciones similar a atRange
	private boolean casillasAdyacentes(Position pos) {
		int rowDiff = Math.abs(this.getPosition().getRow() - pos.getRow());
		int colDiff = Math.abs(this.getPosition().getCol() - pos.getCol());
		// Si está a una casilla de distancia (vertical, horizontal o diagonal)
		return (rowDiff <= 1 && colDiff <= 1) && (rowDiff + colDiff != 0);
	}

}
