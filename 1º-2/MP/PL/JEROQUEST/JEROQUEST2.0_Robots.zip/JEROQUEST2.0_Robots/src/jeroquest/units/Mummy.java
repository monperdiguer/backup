/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * Class that represents a Mummy monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Mummy extends Monster implements Aturdible {

	// initial values for the attributes
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 3;
	protected static final int DEFENCE = 4;
	protected static final int BODY = 2;

	/**
	 * Create a mummy from its name
	 * 
	 * @param name name of the mummy
	 */
	public Mummy(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setDazed(false); // no haría que penalizase no hacerlo, popr defecto en Java es false
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'M';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Icon of a mummy
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/mummy.gif"));

	@Override
	public Icon getImage() {
		return icon;
	}

	// 6-
	private boolean dazed;

	@Override
	public void setDazed(boolean dazed) {
		this.dazed = dazed;
	}

	@Override
	public boolean isDazed() {
		return dazed;
	}

	@Override
	public void resolveTurn() {
		if (isDazed())
			setDazed(false);
		else
			super.resolveTurn();
	}

}
