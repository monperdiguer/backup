/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * Class that represents a Mummy monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Mummy extends Monster implements Serio{

	// initial values for the attributes
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 3;
	protected static final int DEFENCE = 4;
	protected static final int BODY = 2;
	
	private int serio;

	/**
	 * Create a mummy from its name
	 * 
	 * @param name name of the mummy
	 */
	public Mummy(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setSerio(0);
	}
	
	@Override
	public int isSerio() {
		return serio;
	}
	
	@Override
	public void setSerio(int serio) {
		this.serio = serio;
	}
	
	@Override
	public int defend(int impacts) {
		int wounds = super.defend(impacts);
		if(wounds == 0)
			setSerio(isSerio() + 1);
		
		return wounds;
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'M';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Icon of a mummy
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/mummy.gif"));

	@Override
	public Icon getImage() {
		return icon;
	}

}
