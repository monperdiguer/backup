package jeroquest.units;

public interface Perezoso {
	public boolean isPerezoso();
	public void setPerezoso(boolean p);
}
