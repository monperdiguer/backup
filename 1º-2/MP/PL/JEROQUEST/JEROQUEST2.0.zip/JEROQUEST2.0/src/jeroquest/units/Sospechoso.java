package jeroquest.units;

public interface Sospechoso {
	public boolean isViolento();
	public void setViolento(boolean isViolento);
}
