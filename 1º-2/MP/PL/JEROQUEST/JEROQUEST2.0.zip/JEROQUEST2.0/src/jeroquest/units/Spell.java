package jeroquest.units;

public class Spell {
	//2a. Los conjuros se caracterizan por un nombre y un número que es un valor entero 
	private String nombre;
	private int numero;

	public Spell(String nombre, int numero) {
		setNombre(nombre);
		setNumero(numero);
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return String.format(" Spell[nombre=%s, numero=%s]", getNombre(), getNumero());
	}
	
	

}