package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.logic.Controller;

public class RobotHeroe extends Hero {

	protected static final int MOVEMENT = 2;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 2;
	
	public RobotHeroe(String name, String player) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY, player, null);
	}

	@Override
	public char toChar() {
		return 'J';
	}
	
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/robot_J.png"));

	@Override
	public Icon getImage() {
		return icon;
	}
	
	private boolean agresivo;

	public boolean isAgresivo() {
		return agresivo;
	}

	public void setAgresivo(boolean agresivo) {
		this.agresivo = agresivo;
	}
	
	@Override
	public void resolveTurn() {
		if(isAgresivo()) {
			setAgresivo(false);
			actionCombat();
		}
		actionMovement();
	}
	
	@Override
	public int defend(int impacts) {
		setAgresivo(true);
		return super.defend(impacts);
	}
	
	private boolean controlado;

	public boolean isControlado() {
		return controlado;
	}

	public void setControlado(boolean controlado) {
		this.controlado = controlado;
	}
	
	public void aturdir() {
		for(Character c : Controller.getInstance().getCurrentGame().getCharacters()) {
			if(c instanceof Aturdible) {
				((Aturdible)c).setDazed(true);
			}
		}
	}
	
}
