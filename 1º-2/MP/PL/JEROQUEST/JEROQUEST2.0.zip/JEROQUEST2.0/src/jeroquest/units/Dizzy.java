package jeroquest.units;

public interface Dizzy {
	 public void activateDizzy();  //el personaje queda aturdido y su imagen será dizzy.png.
	 public void recover();  //el personaje trata de recuperarse del aturdimiento.
	 public boolean isDizzy(); //que retorna cierto si el personaje está aturdido.

}
