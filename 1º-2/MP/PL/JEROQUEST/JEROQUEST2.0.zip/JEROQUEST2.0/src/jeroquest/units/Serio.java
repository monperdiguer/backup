package jeroquest.units;

public interface Serio {
	public int isSerio();
	public void setSerio(int serio);
}
