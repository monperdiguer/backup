package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;

public class Cazarecompensas extends Character {

	protected static final int MOVEMENT = 10;
	protected static final int ATTACK = 4;
	protected static final int DEFENCE = 4;
	protected static final int BODY = 6;

	private DynamicVectorCharacters lista;
	private int beneficio;
	
	
	public Cazarecompensas(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		
	}

	
	public DynamicVectorCharacters getLista() {
		return lista;
	}


	public void setLista(DynamicVectorCharacters lista) {
		this.lista = lista;
	}

	public void obtenerLista() {
		setLista(new DynamicVectorCharacters());
		for (Character personaje : Controller.getInstance().getCurrentGame().getCharacters())
			if (!(personaje instanceof Cazarecompensas) && personaje.isAlive() && Dice.roll(4) == 1)
				getLista().add(personaje);
	}

	@Override
	public char toChar() {
		return 'H';
	}
	
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/hunter.png"));
	
	@Override
	public Icon getImage() {
		return icon;
	}
	

	@Override
	public int defend(int impacts) {
			int wounds = 0;
			
		//YO LO HICE DIFERENTE	
			if(beneficio > 0)
				setDefence(getDefence()*2);
			
			for (int totalDefenceDices = getDefence(); (impacts > 0) && (totalDefenceDices > 0); totalDefenceDices--)
				if (Dice.roll() > 4) // a 5 or 6 necessary to block an impact
					impacts--;

			// if any unblocked impact, decrement body points
			if (impacts > 0) {
				// the life of a character cannot be lower then zero
				wounds = Math.min(getBody(), impacts);
				setBody(getBody() - wounds);	
			}
			return wounds;
	}


	@Override
	public boolean isEnemy(Character personaje) {
		return getLista().member(personaje) || personaje instanceof Recompensable;
	}

}
