/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.boardgame.Position;
import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;
import jeroquest.utils.DynamicVectorSpells;

/**
 * Class that represents a Dwarf hero character in the game
 *
 * @author Programming Methodology Professors
 */
public class Wizards extends Hero {
	// initial values for the attributes
	protected static final int MOVEMENT = 5;
	protected static final int ATTACK = 0;
	protected static final int DEFENCE = 1;
	protected static final int BODY = 4;
	
	private DynamicVectorSpells libro;

	/**
	 * Create a dwarf from its name and the player name
	 * 
	 * @param name   dwarf's name
	 * @param player name of the player that controls it
	 */
	public Wizards(String name, String player) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY, player, new Weapon("Bastón de mago", 1));
		
		libro = new DynamicVectorSpells();
		this.generateSpell();
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	public DynamicVectorSpells getLibro() {
		return libro;
	}

	public void setLibro(DynamicVectorSpells libro) {
		this.libro = libro;
	}
	
	public void generateSpell() {
		int valor = Dice.roll(10);
		if(valor < 8) {
			libro.add(new Spell("Invisibilidad", 0));
			Controller.getInstance().updateGraphicalPiece(null, String.format("%s ha añadido el conjuro Invisibilidad a su libro de conjuros", this.getName()));
		}
		else
			libro.add(new Spell("Proyectil mágico", Dice.roll(3)));
			Controller.getInstance().updateGraphicalPiece(null, String.format("%s ha añadido el conjuro Proyectil mágico a su libro de conjuros", this.getName()));
	}
	
	public boolean hasSpell(String spellName) {
		for(int i = 0; i < libro.length(); i++) {
			if(libro.get(i).getNombre().equals(spellName))
				return true;
		}
		return false;
	}
	
	public void removeASpell(String spellName) {
		for(int i = 0; i < libro.length(); i++) {
			if(libro.get(i).getNombre().equals(spellName))
				libro.remove(i);
				Controller.getInstance().updateGraphicalPiece(null, String.format("%s ha desaparecido de su libro de conjuros", this.getName()));
		}
	}
	
	@Override
	public int defend(int impacts) {
		if(hasSpell("Invisibilidad")) {
			this.removeASpell("Invisibilidad");
			return 0;
		}
		return super.defend(impacts);
	}
	
	@Override
	public boolean actionCombat() {
		if(!hasSpell("Proyectil mágico")) {
			return super.actionCombat();
		}
		
		// Attack a random enemy
		DynamicVectorCharacters targets = validTargets();

		if (targets.length() > 0) {
			//Lanza el proyectil
			Controller.getInstance().updateGraphicalPiece(null, String.format("%s lanza Proyectil mágico", this.getName()));
			
			for (int i = 0; i < targets.length(); i++) {								
				Character target = targets.get(i);
				String message = String.format("%s %s attacks to %s %s", getName(), getPosition(), target.getName(), target.getPosition());
				Controller.getInstance().updateGraphicalPiece(null, message);
				this.combat(target);
			}
			
			this.removeASpell("Proyectil mágico");
			return true;
		}
		return false;
	}
	
	@Override
	public boolean isAtRange(Position pos) {
		if(hasSpell("Proyectil mágico")) {
			if ((this.getPosition().getRow() == pos.getRow() - 1) && (this.getPosition().getCol() == pos.getCol() - 1))
				return true;

			if ((this.getPosition().getRow() == pos.getRow() + 1) && (this.getPosition().getCol() == pos.getCol() - 1))
				return true;

			if ((this.getPosition().getCol() == pos.getCol() - 1) && (this.getPosition().getRow() == pos.getRow() + 1))
				return true;

			if ((this.getPosition().getCol() == pos.getCol() + 1) && (this.getPosition().getRow() == pos.getRow() + 1))
				return true;
		}
		return super.isAtRange(pos);
	}
	
	@Override
	public int getAttack() {	
		for (int i = 0 ; i < libro.length(); i++)
			if (libro.get(i).getNombre().equals("Proyectil magico"))			
				return libro.get(i).getNumero();
		
		return super.getAttack();	
	}
	
	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'W';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Dwarf icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/wizard.jpg"));

	@Override
	public Icon getImage() {
		return icon;
	}

}
