package jeroquest.units;

public interface Aturdible {
	
	public boolean isDazed();
	
	public void setDazed(boolean artudido);
}
