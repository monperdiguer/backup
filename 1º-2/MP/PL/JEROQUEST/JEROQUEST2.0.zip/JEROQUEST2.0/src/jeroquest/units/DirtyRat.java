/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * Class that represents a DirtyRat monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class DirtyRat extends Monster {

	// initial values for the attributes
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 5;
	
	//protected boolean fearful = false;
	private boolean fearful;

	/**
	 * Create a dirty rat from its name
	 * 
	 * @param name dirty rat's name
	 */
	public DirtyRat(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setFearful(false);
	}
	
	/************************************************
	 * Interface Piece implementation
	 **********************************************/
	
	public boolean fearful() {
		return fearful();
	}
	
	public void setFearful(boolean fearful) {
		this.fearful  = fearful;
	}

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'R';
	}
	
	@Override
	public boolean isEnemy(Character c) {
		return (super.isEnemy(c) || c.getBody() < this.getBody());
	}
	
	@Override
	public int defend(int impacts){
		int wounds = super.defend(impacts);
		if( wounds > 0){
			if(this.fearful && wounds >=(this.getMaxBody() / 2))
				this.setBody(0);
			else
				this.fearful =  true;
		}
		else
			this.fearful = false;
		return wounds;
	}

	@Override
	public void resolveTurn() {
		if(!fearful())
		 super.resolveTurn();
	}

	public void regenerate() {
		if(this.getBody() < this.getMaxBody())
			this.setBody(this.getBody() + 1);
			
	}
	

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Goblin icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/rata.png"));
	private static Icon icon2 = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/rata_asustada.png"));
	
	@Override
	public Icon getImage() {
		if(fearful())
			return icon2;
		else return icon;
	}
	

}
