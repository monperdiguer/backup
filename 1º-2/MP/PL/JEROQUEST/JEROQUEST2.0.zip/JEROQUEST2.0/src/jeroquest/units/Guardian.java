package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;


public class Guardian extends Monster{

	/**
	 * Create a monster from its name and initial values for the attributes,
	 * initially its position is null (outside of the board)
	 * 
	 * @param name     name of the character
	 * @param movement squares to move per turn
	 * @param attack   dices to roll for an attack without a weapon
	 * @param defence  dices to roll for the defence
	 * @param body     initial life
	 */
	
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 5;
	
	
	public Guardian(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
	}

	/**
	 * The monster defends itself from an attack (Implementation of an abstract
	 * inherited method)
	 * 
	 * @param impacts the total number of impacts to try to block or suffer
	 * @return the number of suffered wounds
	 */
	@Override
	public int defend(int impacts) {
		return 0;
	}

	/**
	 * Check if the character given as argument is an enemy of the current one. An
	 * enemy will be all characters that are monsters (Overridden method)
	 * 
	 * @param c character to check
	 * @return true if it an enemy of the current character
	 */
	@Override
	public boolean isEnemy(Character c) {
		return c instanceof Sospechoso && ((Sospechoso)c).isViolento();
	}
	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'X';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Goblin icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/guardian.png"));
	@Override
	public Icon getImage() {
		return icon;
	}
	
	/* TO DO
	 * @Override
	public boolean actionCombat() {
		DynamicVectorCharacters targets = validTargets();
		
		if(targets.length() > 0) {
			for(int i = 0; i < targets.length(); i++) { //penaliza a todos
				if(targets.get(i) instanceof Hero) {
					Hero h = ((Hero)targets.get(i));
					
				}
			}
			
		}
	*/
}
