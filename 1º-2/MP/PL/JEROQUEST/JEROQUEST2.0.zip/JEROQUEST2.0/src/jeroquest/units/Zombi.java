/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;

/**
 * Class that represents a Goblin monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Zombi extends Monster {

	// initial values for the attributes
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 3;
	protected static final int DEFENCE = 0;
	protected static final int BODY = 3;

	/**
	 * Create a goblin from its name
	 * 
	 * @param name goblin's name
	 */
	public Zombi(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'Z';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Goblin icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/zombi.gif"));
	@Override
	public Icon getImage() {
		return icon;
	}
	
	@Override
	public int defend(int impacts) {
		return super.defend(0);
	}
	
	@Override
	public boolean actionCombat() {
		// Attack a random enemy
		DynamicVectorCharacters targets = validTargets();

		if (targets.length() > 0) {
			Character target = null;
			
			//primero busca un barbaro
			for(int x = 0; x < targets.length() && target == null; x++)
				if(targets.get(x) instanceof Barbarian)
					target = targets.get(x);
				if(target == null)
					target = targets.get(Dice.roll(targets.length()) - 1);
				
				String message = String.format("%s %s attacks to %s %s", getName(), getPosition(), target.getName(),
						target.getPosition());
				Controller.getInstance().updateGraphicalPiece(null, message);
				return true;
		}
		else
			return false;
	}
	public void degradation() {
		if(this.getBody() > 0)
			this.setBody(this.getBody() - 1);
	}
}
