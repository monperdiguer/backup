/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;

/**
 * Class that represents a Goblin monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Joker extends Monster {

	// initial values for the attributes
	protected static final int MOVEMENT = 6;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 1;
	protected static final int BODY = 3;
	
	private DynamicVectorCharacters lista;

	/**
	 * Create a goblin from its name
	 * 
	 * @param name goblin's name
	 */
	public Joker(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		lista = new DynamicVectorCharacters();
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	public DynamicVectorCharacters getLista() {
		return lista;
	}

	public void setLista(DynamicVectorCharacters lista) {
		this.lista = lista;
	}

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'J';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Goblin icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/joker.png"));
	@Override
	public Icon getImage() {
		return icon;
	}
	
	@Override
	public boolean isEnemy(Character c) {
		return (super.isEnemy(c) || c instanceof Serio );
	}
	
	@Override
	public boolean actionCombat() {
		// Attack a random enemy
		DynamicVectorCharacters targets = validTargets();

		if (targets.length() > 0) {
			Character target = null;
			for(int i = 0; i < targets.length(); i++) {
				if(targets.get(i) instanceof Serio)
					target = targets.get(i);
			}
		
			if(target == null) {
				target = targets.get(Dice.roll(targets.length()) - 1);
				String message = String.format("%s %s attacks to %s %s", getName(), getPosition(), target.getName(),
					target.getPosition());
				Controller.getInstance().updateGraphicalPiece(null, message);
				this.combat(target);

			return true;
			}
		}
		return false;
	}
	
	@Override
	public void combat(Character c) {
		/*Si no estuviera el ejercicio 5 y solo tuvieramos que hacer la segunda parte del ejercicio 4
		 * int previuosBody = c.getBody();
		 * super.combat(c); //porque esta implementación no sirve
		 * if((c.getBody() < c.previousBody) && (!lista.member(c)))
		 * 	lista.add(c);
		 */
		int impacts = this.attack();
		//Ejercicio 5
		if(c instanceof Serio) {
			impacts += ((Serio)c).isSerio();
		}
		int wounds = c.defend(impacts);
		if (!c.isAlive()) {
			Controller.getInstance().getCurrentGame().getBoard().removePiece(c);
		}
		if (wounds > 0) {
			//Ejercicio 4
			if(!lista.member(c))
				lista.add(c);
			Controller.getInstance().updateGraphicalPiece(c, String.format("%s cannot block %d impacts%s", c.getName(),
					wounds, (c.isAlive() ? "" : " and dies")));
		} else {
			Controller.getInstance().updateGraphicalPiece(null, String.format("%s blocks the attack", c.getName()));
		}
		
	}
	
	public void molestar() {
		for(int i = 0; i < lista.length(); i++) {
			if(lista.get(i).isAlive()) {
				lista.get(i).setName(lista.get(i).getName() + 'J');
				if(lista.get(i) instanceof Serio)
					lista.get(i).setName(lista.get(i).getName()+ 'J' + ((Serio) lista.get(i)).isSerio()) ;
			
			}
		}
		
		
	}


}
