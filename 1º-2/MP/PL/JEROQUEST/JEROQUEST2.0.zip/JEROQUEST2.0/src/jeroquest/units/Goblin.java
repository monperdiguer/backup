/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * Class that represents a Goblin monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Goblin extends Monster implements Perezoso{

	// initial values for the attributes
	protected static final int MOVEMENT = 10;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 1;
	protected static final int BODY = 1;
	
	private boolean perezoso;

	/**
	 * Create a goblin from its name
	 * 
	 * @param name goblin's name
	 */
	public Goblin(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setPerezoso(false);
	}
	

	public boolean isPerezoso() {
		return perezoso;
	}



	public void setPerezoso(boolean perezoso) {
		this.perezoso = perezoso;
	}

	@Override
	public int actionMovement() {
		int steps = super.actionMovement();
		if(getMovement()  == getMaxMovement()) {
			setPerezoso(true);
		}
		return steps;
	}
	
	/************************************************
	 * Interface Piece implementation
	 **********************************************/


	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'G';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Goblin icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/goblin.png"));
	@Override
	public Icon getImage() {
		return icon;
	}

}
