/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.utils;
import jeroquest.units.Character;
import jeroquest.units.Spell;

/**
 * Class that allows to represent dynamic vectors of Spell
 *
 * @author Programming Methodology Professors
 */
public class DynamicVectorSpells extends DynamicVectorObjects {

	public DynamicVectorSpells() {

	}

	public DynamicVectorSpells(DynamicVectorSpells vDE) {
		super(vDE);
	}

	public DynamicVectorSpells(int size) {
		super(size);
	}

	public DynamicVectorSpells(Character[] v) {
		super((Object[]) v);
	}

	@Override
	public Spell get(int i) {
		return (Spell) super.get(i);
	}

	// Other methods
	@Override
	public Spell[] vectorNormal() { // returns a Character[] as the integers of vOI
		Spell[] temp = new Spell[this.length()];
		for (int i = 0; i < temp.length; i++)
			temp[i] = this.get(i);
		return temp;
	}

	@Override
	public String toString() {
		String s = "";	
		for (int i = 0 ; i < length(); i++)
			s += this.get(i);		
		return s;
	}
	
}
