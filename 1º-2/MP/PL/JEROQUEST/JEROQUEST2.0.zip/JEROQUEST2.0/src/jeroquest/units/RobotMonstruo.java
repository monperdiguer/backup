package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.logic.Controller;
import jeroquest.utils.DynamicVectorCharacters;

public class RobotMonstruo extends Monster{
	
	protected static final int MOVEMENT = 2;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 2;
	
	public RobotMonstruo(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setPersonajesAtacados(new DynamicVectorCharacters());
	}
	
	@Override
	public char toChar() {
		return 'C';
	}
	
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/robot_C.png"));
	@Override
	public Icon getImage() {
		return icon;
	}
	
	private boolean fallo;

	public boolean isFallo() {
		return fallo;
	}

	public void setFallo(boolean fallo) {
		this.fallo = fallo;
	}
	
	@Override
	public int defend(int impacts) {
		int wounds = super.defend(impacts);
		if(impacts > 1) {
			setFallo(true);
		}
		return wounds;
	}
	
	@Override
	public void combat(Character c) { // attacks to c and c defends itself
		
		if(c instanceof Monster) {
			setFallo(false);
		}
		
		int impacts = this.attack();
		
		if(getPersonajesAtacados().member(c)) {
			impacts *= 2;
		}
		else getPersonajesAtacados().add(c);
		
		int wounds = c.defend(impacts);
		if (!c.isAlive()) {
			Controller.getInstance().getCurrentGame().getBoard().removePiece(c);
		}
		if (wounds > 0) {
			Controller.getInstance().updateGraphicalPiece(c, String.format("%s cannot block %d impacts%s", c.getName(),
					wounds, (c.isAlive() ? "" : " and dies")));
		} else {
			Controller.getInstance().updateGraphicalPiece(null, String.format("%s blocks the attack", c.getName()));
		}
	}
	
	@Override
	public boolean isEnemy(Character c) {
		if(isFallo())
			return true;
		return super.isEnemy(c);
	}
	
	private DynamicVectorCharacters personajesAtacados;

	public DynamicVectorCharacters getPersonajesAtacados() {
		return personajesAtacados;
	}

	public void setPersonajesAtacados(DynamicVectorCharacters personajesAtacados) {
		this.personajesAtacados = personajesAtacados;
	}
	
	
}
