package jeroquest.units;

public interface Recompensable {

}
