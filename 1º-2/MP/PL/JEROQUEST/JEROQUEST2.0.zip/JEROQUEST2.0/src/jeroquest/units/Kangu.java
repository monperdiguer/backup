/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Position;
import jeroquest.logic.Controller;
import jeroquest.logic.Game;
import jeroquest.utils.DynamicVectorPosition;

/**
 * Class that represents a Goblin monster character in the game
 *
 * @author Programming Methodology Professors
 */
public class Kangu extends Monster {

	// initial values for the attributes
	protected static final int MOVEMENT = 3;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 1;
	protected static final int BODY = 4;
	
	private boolean exhausted;
	private int angryTurns;
	
	/**
	 * Create a goblin from its name
	 * 
	 * @param name goblin's name
	 */
	public Kangu(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		setExhausted(false);
		setAngryTurns(0);
	}
	
	public boolean isExhausted() {
		return exhausted;
	}
	
	public void setExhausted(boolean exhausted) {
		this.exhausted = exhausted;
	}
	
	/**
	 * @return the angryTurns
	 */
	public int getAngryTurns() {
		return angryTurns;
	}

	/**
	 * @param angryTurns the angryTurns to set
	 */
	public void setAngryTurns(int angryTurns) {
		// the number of turns cannot be lower than 0
		this.angryTurns = Math.max(0, angryTurns);
	}
	
	@Override
	public boolean isEnemy(Character c) {
		if(this.getAngryTurns() != 0)
			return (super.isEnemy(c));
		else
			return false;
	}
	
	@Override
	public int defend(int impacts) {
		int wounds = super.defend(impacts);
		if(wounds > 0)
			this.setAngryTurns(this.getAngryTurns() + 2);
		
		return wounds;
	}
	
	@Override
	public void combat(Character c) {
		int previous = c.getBody();
		super.combat(c);
		// Exercise 2
		if (c.getBody() < previous && this.getAngryTurns() > 0)
			setAngryTurns(getAngryTurns() + 2);
		if((c instanceof Dizzy) && (c.isAlive()))
			((Dizzy)c).activateDizzy();
	}
	
	@Override
	public void resolveTurn() {
		setAngryTurns(getAngryTurns() - 1);
		super.resolveTurn();
	}
	
	@Override
	public int attack() {
		int impacts = super.attack();
		if (impacts > 0)
			impacts++;
		return impacts;
	}
	 @Override
	 public DynamicVectorPosition validPositions() {

			DynamicVectorPosition positions = new DynamicVectorPosition();
			Game currentGame = Controller.getInstance().getCurrentGame();

			Position position = this.getPosition().east().south();
			if (currentGame.getBoard().freeSquare(position))
				positions.add(position);

			position = this.getPosition().west().south();
			if (currentGame.getBoard().freeSquare(position))
				positions.add(position);

			position = this.getPosition().east().north();
			if (currentGame.getBoard().freeSquare(position))
				positions.add(position);

			position = this.getPosition().west().north();
			if (currentGame.getBoard().freeSquare(position))
				positions.add(position);

			return positions;
		}
	 
	 @Override
	 public int actionMovement() {
		 int movimientos = 0;
		 if(this.isExhausted()) {
			 System.out.println(this.getName() + "is exhausted, and odesn't move");
			 this.setExhausted(false);
		 }
		 else {
			 movimientos = super.actionMovement();
			 if(movimientos == this.getMovement())
				 this.setExhausted(true);;
		 }
		 return movimientos;
	 }
	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'K';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Goblin icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/kanguHappy.png"));
	private static Icon icon2 = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/kanguAngry.png"));
	@Override
	public Icon getImage() {
		if(this.getAngryTurns() > 0)
			return icon2;
		else return icon;
	}

}
