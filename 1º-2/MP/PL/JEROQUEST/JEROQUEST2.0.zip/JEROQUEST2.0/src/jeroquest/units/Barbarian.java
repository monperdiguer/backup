/*
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * 
 * @author Programming Methodology Professors
 *
 */
package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;

/**
 * Class that represents a Barbarian hero character in the game
 *
 * @author Programming Methodology Professors
 */
public class Barbarian extends Hero implements Dizzy, Serio{
	// initial values for the attributes
	protected static final int MOVEMENT = 7;
	protected static final int ATTACK = 1;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 8;
	private boolean dizzy;
	private int serio;

	/**
	 * Create a barbarian from its name and the player name
	 * 
	 * @param name   barbarian's name
	 * @param player name of the player that controls it
	 */
	public Barbarian(String name, String player) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY, player, new Weapon("Broadsword", 3));
		this.setDizzy(false);
		setSerio(0);
		
	}

	private void setDizzy(boolean d) {
		this.dizzy = d;
	}
	
	@Override
	public void recover() {
		if(Dice.roll() == 6)
			this.dizzy = false;
	}
	
	@Override
	public void activateDizzy() {
		this.dizzy = true;
	}
	
	@Override
	public boolean isDizzy() {
		return this.dizzy;
	}
	
	@Override
	public int isSerio() {
		return this.serio;
	}
	
	@Override
	public void setSerio(int serio) {
		this.serio = serio;
	}
	
	@Override
	public void resolveTurn() {
		super.resolveTurn();
		if(getWeapon() != null && getBody() == getMaxBody())
			setSerio(isSerio() + 1);
	}
	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	@Override
	public char toChar() {
		return 'B';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Barbarian icon
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/barbarian.gif"));
	private static Icon icon2 = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/dizzy.gif"));
	@Override
	public Icon getImage() {
		if(this.isDizzy())
			return icon2;
		else return icon;
	}

}
