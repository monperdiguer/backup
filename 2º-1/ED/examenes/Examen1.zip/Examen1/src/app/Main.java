package app;

import estdatos.CharacterArray;

public class Main {
	public static void main(String[] args) {
		//instancia un character array
		CharacterArray ca=new CharacterArray();
		ca.add('b');
		ca.add('o');
		ca.add('b');
		ca.add('o');
		ca.add('e');
		CharacterArray ca2=new CharacterArray("bobo");
		for(Character c:ca2) {
			System.out.print(c);
		}
		System.out.println();
		System.out.println(ca);
		System.out.println("ca=ca2: "+ca.compareTo(ca2));
	}
}
