package estdatos;

import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class CharacterArray extends AbstractCollection<Character> implements Comparable<CharacterArray>{

	//area de datos
	private Character[] characters;
	private int size;
	
	public CharacterArray() {
		characters=new Character[10];
		this.size=0;
	}
	
	public CharacterArray(CharacterArray c) {
		this();
		for(Character car:c) {
			this.add(car);
		}
	}
	
	public CharacterArray(String s) {
		this();
		for(int i=0;i<s.length();i++) {
			this.add((Character)s.charAt(i));
		}
	}
	
	public boolean add(Character ch) {
		ensureCapacity();
		characters[size]=ch;
		size++;
		return true;
	}
	

	
	
	@Override
	public Iterator<Character> iterator() {
		return new Iterator<Character>() {
			private int index=0;
			
			@Override
			public boolean hasNext() {
				return index<size;
			}

			@Override
			public Character next() {
				if(!hasNext()) {
					throw new NoSuchElementException();
				}
				Character ch=characters[index];
				index++;
				return ch;
			}
		};
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}
	
	protected void ensureCapacity(){
		int capacity=characters.length;
		if (size == capacity){ 
			Character[] newData = new Character[capacity*2+1]; 
			System.arraycopy(characters, 0, newData, 0, size); 
			characters = newData; 
		} 
	}

	@Override
	public int compareTo(CharacterArray o) {
		int minSize=Math.min(this.size,o.size);
		for(int i=0;i<minSize;i++) {
			int valor=this.characters[i].compareTo(o.characters[i]);  //comparo caracter i con caracter i
			if(valor!=0)		//si es distinto de cero uno es menor
				return valor;	//return el valor de comparacion
								// si es igual a cero  sigo
		}
		//aqui llegamos si hasta minSize son iguales
		return Integer.compare(this.size, o.size);	//devuelvo la comparacion de los tamaños
	}

	@Override 
	public String toString() {
		StringBuilder s=new StringBuilder();	//creo un stringbuilder
		for(int i=0;i<size;i++) {				//añado caracter a caracter
			s.append(characters[i]);
		}
		return s.toString();
	}
	
}
